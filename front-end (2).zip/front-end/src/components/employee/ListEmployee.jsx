import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import axios from "axios";
import {
  Badge,
  Card,
  CardBody,
  CardHeader,
  Col,
  Pagination,
  PaginationItem,
  PaginationLink,
  Row,
  Table,
} from "reactstrap";

const ListEmployee = (props) => {
  const [data, setData] = useState([]);
  useEffect(() => {
    const getData = async () => {
      const result = await axios("http://localhost:8080/api/employee/all");
      console.log(result.data);
      setData(result.data);
    };
    getData();
  }, []);
  const deleteemployee = (id) => {
    axios
      .delete("http://localhost:8080/api/employee/delete/" + id)
      .then((result) => {
        props.history.push("/");
      });
  };
  const editemployee = (id) => {
    props.history.push({
      pathname: "/edit/" + id,
    });
  };
  return (
    <div className="animated fadeIn">
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <i className="fa fa-align-justify"></i> Employee List
            </CardHeader>

            <CardBody>
              <Table hover bordered striped responsive size="sm">
                <thead>
                  <tr>
                    <th>Employee Id</th>

                    <th>FirstName</th>

                    <th>LastName</th>

                    <th>Extension</th>

                    <th>Email</th>

                    <th>Office Code</th>

                    <th>Reports To</th>

                    <th>Job Title</th>
                  </tr>
                </thead>

                <tbody>
                  {data.map((item, idx) => {
                    return (
                      <tr key={idx}>
                        <td>{item.employeeId}</td>

                        <td>{item.firstName}</td>

                        <td>{item.lastName}</td>

                        <td>{item.extension}</td>

                        <td>{item.email}</td>

                        <td>{item.officeCode}</td>

                        <td>{item.reportsTo}</td>

                        <td>{item.jobTitle}</td>

                        <td>
                          <div class="btn-group">
                            <button
                              className="btn btn-warning"
                              onClick={() => {
                                editemployee(item.employeeId);
                              }}
                            >
                              Edit
                            </button>

                            <button
                              className="btn btn-warning"
                              onClick={() => {
                                deleteemployee(item.employeeId);
                              }}
                            >
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

ListEmployee.propTypes = {};

export default ListEmployee;
